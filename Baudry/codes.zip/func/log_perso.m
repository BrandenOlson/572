function f=log_perso(x)

f=log(max(x,10^(-300)));
